V0.1

- Time functionality
- Scene managment
- Basic UI
- Terminal/Console
- Folder structure
- Updated to Unity 2019.4.11f
